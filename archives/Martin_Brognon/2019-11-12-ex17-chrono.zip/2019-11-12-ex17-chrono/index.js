"use strict";
/*let $btnStart = document.getElementById("btnStart");
let $btnLap = document.getElementById("btnLap");
let $btnStop = document.getElementById("btnStop");
let $btnReset = document.getElementById("btnReset");
let $span = document.getElementsByTagName("span");
let $t;
let $millisecondes = 0;
let $secondes = 0;
let $minutes = 0;
let $heures = 0;
let $blankRow = document.getElementById("divRow").cloneNode(true);
$blankRow.removeAttribute("id");
$blankRow.setAttribute("id", "divRow");
let $divResult = document.getElementById("divResult");

$divResult.innerHTML = "";

$btnStart.addEventListener("click", start);
$btnLap.addEventListener("click", lap);
$btnStop.addEventListener("click", stop);
$btnReset.addEventListener("click", reset);

function start() {
    $t = setInterval(incCpt, 100);
    $btnStart.setAttribute("disabled", "");
    $btnLap.removeAttribute("disabled");
    $btnStop.removeAttribute("disabled");
    $btnReset.setAttribute("disabled", "");
}

function lap() {
    let $newRow = $blankRow.cloneNode(true);
    $t = $heures + " h " + $minutes + " m " + $secondes + " s " + $millisecondes + " ms";
    $newRow.innerHTML = $t;
    $divResult.appendChild($newRow);
}

function stop() {
    clearInterval($t);
    $btnStart.removeAttribute("disabled");
    $btnLap.setAttribute("disabled", "");
    $btnStop.setAttribute("disabled", "");
    $btnReset.removeAttribute("disabled");
}

function incCpt() {
    $millisecondes += 1;
    if($millisecondes === 10) {
        $millisecondes = 1;
        $secondes += 1;
    }

    if($secondes === 60) {
        $secondes = 0;
        $minutes += 1;
    }

    if($minutes === 60) {
        $minutes = 0;
        $heures += 1;
    }

    $span[0].innerHTML = $heures + " h";
    $span[1].innerHTML = $minutes + " m";
    $span[2].innerHTML = $secondes + " s";
    $span[3].innerHTML = $millisecondes + " ms";
}

function reset() {
    clearInterval($t);
    $millisecondes = 0;
    $secondes = 0;
    $minutes = 0;
    $heures = 0;
    $btnStart.removeAttribute("disabled");
    $btnLap.removeAttribute("disabled");
    $btnStop.setAttribute("disabled", "");
    $btnReset.setAttribute("disabled", "");
    $span[0].innerHTML = $heures + " h";
    $span[1].innerHTML = $minutes + " m";
    $span[2].innerHTML = $secondes + " s";
    $span[3].innerHTML = $millisecondes + " ms";
}*/

const $btnStart = document.getElementById("btnStart");
const $btnLap = document.getElementById("btnLap");
const $btnStop = document.getElementById("btnStop");
const $btnReset = document.getElementById("btnReset");
const $txtChrono = document.getElementById("txtChrono");
const $divLap = document.getElementById("divLap");

$btnStart.addEventListener("click", startChrono);
$btnLap.addEventListener("click", lapChrono);
$btnStop.addEventListener("click", stopChrono);
$btnReset.addEventListener("click", resetChrono);

resetChrono();

// Variables globales
let startTime; // L'heure de début du chronométrage qui est une variable globale
let timer; // Gestion du timer d'affichage du chrono

function startChrono() {
    startTime = new Date(); // On stocke la valeur

    timer = setInterval(affChrono, 1);

    $btnStart.disabled = true;
    $btnStop.disabled = false;
    $btnLap.disabled = false;
    $btnReset.disabled = true;
}

function stopChrono() {
    let now = new Date(); // L'heure actuelle
    clearInterval(timer);

    let time = now - startTime; // Durée en millisecondes
    $divLap.innerHTML += tps2String(time) + "<br>";

    $txtChrono.value = tps2String(time); // Correction pour éviter des différences d'affichage entre l'affichage du chrono et l'affichage du lap

    $btnStart.disabled = true;
    $btnStop.disabled = true;
    $btnLap.disabled = true;
    $btnReset.disabled = false;
}

function lapChrono() {
    let now = new Date(); // L'heure actuelle
    let time = now - startTime; // Durée en millisecondes
    $divLap.innerHTML += tps2String(time) + "<br>";
}

function resetChrono() {
    $divLap.innerHTML = "";
    $txtChrono.value = tps2String(0);

    $btnStart.disabled = false;
    $btnStop.disabled = true;
    $btnLap.disabled = true;
    $btnReset.disabled = true;
}

// Fonction appelée toutes les 1 millisecondes
function affChrono() {
    let now = new Date();
    let time = now - startTime; // Durée en millisecondes
    $txtChrono.value = tps2String(time);
}

// fonction qui convertit des millisecondes au format hh:mm:ss,ms
function tps2String(tps_ms) {
    let temps = new Date(tps_ms);

    let heures = temps
        .getUTCHours()
        .toString()
        .padStart(2, "0");

    let minutes = temps
        .getUTCMinutes()
        .toString()
        .padStart(2, "0");

    let secondes = temps
        .getUTCSeconds()
        .toString()
        .padStart(2, "0");

    let millisec = temps
        .getUTCSeconds()
        .toString()
        .padStart(3, "0");

    return heures + ":" + minutes + ":" + secondes + "," + millisec;
}