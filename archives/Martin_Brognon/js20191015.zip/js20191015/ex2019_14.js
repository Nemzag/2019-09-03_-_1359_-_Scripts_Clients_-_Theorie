//---------------------------------
let $divUsers = document.getElementById("divUsers");
let $txtFiltreNom = document.getElementById("txtFiltreNom");
//---------------------------------
$txtFiltreNom.addEventListener("keyup", maj_users);
//---------------------------------
function maj_users() {
	$divUsers.innerHTML = "";
	fetch("https://jsonplaceholder.typicode.com/users")
		.then($reponse => $reponse.json())
		.then($data => {
			// Pour comparer, on part du principe que ABC est plus grand que XYZ en ASCII.
			$data = $data.sort(($a,$b) => $a.name.localeCompare($b.name)); // Comme on utilise du JSON, il faut utiliser la fonction localeCompare().
			try {
				let $filtre = new RegExp($txtFiltreNom.value); // Expression régulière
				for (const USER of $data) {
					if ($filtre.test(USER.name)) {
						let $pUser = document.createElement("p");
						let $texte = document.createTextNode(
							`nom: ${USER.name} ville: ${USER.address.city}` // ${} en PHP on peut utiliser directement des variables, ils ont décidé que le blockquote sont l'affichage, et si on veut appeler la variable, on doit employer ${} dans ce cas.
						);
						$pUser.appendChild($texte);
						$divUsers.appendChild($pUser);
					}
				}
			} catch ($e) {
				console.log("e :", $e);
			}
		});
}
//---------------------------------
