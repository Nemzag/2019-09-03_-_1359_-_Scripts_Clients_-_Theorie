//---------------------------------
document.getElementById("btnReq").addEventListener("click", reqAjax_v2);
//---------------------------------

function reqAjax() {
	let $num = document.getElementById("txtNum").value;

	fetch("./ex2019_12.php?num=" + $num) //création XMLHttpRequest, open, send + renvoi Promise
		.then(function($reponse) {
			// onreadystatechange avec readyState === 4
			return $reponse.json(); //renvoie un Promise
		})
		.then(function($data) {
			let $texte = "";
			for (const ITEM in $data) {
				$texte += ITEM + " : " + $data[ITEM] + "<br />";
			}
			document.getElementById("divResult").innerHTML = $texte;
		})
		.catch(function() {
			// pas de réponse pour l'url encodée
			alert("ERREUR");
		});
}
function reqAjax_v2() {
	let $num = document.getElementById("txtNum").value;

	fetch("./ex2019_12.php?num=" + $num) //création XMLHttpRequest, open, send + renvoi Promise
		.then($reponse => $reponse.json())
		.then($data => {
			console.log("data :", $data);
			let $texte = "";
			for (const ITEM in $data) {
				$texte += ITEM + " : " + $data[ITEM] + "<br />";
			}
			document.getElementById("divResult").innerHTML = $texte;
		})
		.catch(() => {
			alert("ERREUR");
		});
}
//---------------------------------
