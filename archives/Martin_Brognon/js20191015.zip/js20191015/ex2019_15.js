"use strict";

// Personnes est un tableau, un map.
// Si on veut trier le tableau par ordre alphabétique, il faut appliquer une fonction de tri sur les noms dans l'ordre croissant avant de lire les données du tableau.

for (const PERS of $personnes) {
    let $tr = document.createElement("tr");
    let $tdNom = document.createElement("td");
    $tdNom.innerHTML = PERS.nom;
    let $tdPrenom = document.createElement("td");
    $tdPrenom.innerHTML = PERS.prenom;
    $tr.appendChild($tdNom);
    $tr.appendChild($tdPrenom);
    document.getElementById("tbody").appendChild($tr);
}