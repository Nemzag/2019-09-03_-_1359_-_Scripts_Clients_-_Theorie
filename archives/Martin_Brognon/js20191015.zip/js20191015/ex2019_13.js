//---------------------------------
document.getElementById("btnMajUsers").addEventListener("click", maj_users);
//---------------------------------

function maj_users() {
	let $divUsers = document.getElementById("divUsers");

	fetch("https://jsonplaceholder.typicode.com/users")
		.then($reponse => $reponse.json())
		.then($data => {
			//console.log("data :", data);
			for (const USER of $data) {
				//console.log("user.address.city :", user.address.city);
				let $pUser = document.createElement("p");
				let $texte = document.createTextNode(USER.name);
				$pUser.appendChild($texte);
				$divUsers.appendChild($pUser);
			}
		});
}

function maj_users2() {
	let $divUsers = document.getElementById("divUsers");

	fetch("https://jsonplaceholder.typicode.com/users")
		.then($reponse => $reponse.json())
		.then($data => {
			let $texte = "";
			let $num = 0;
			for (const USER of $data) {
				$num++;
				let $texte =
					"" +
					$num +
					". " +
					USER.name +
					" (" +
					USER.username +
					") [" +
					USER.address.city +
					"]";
				let $pUser = document.createElement("p");
				$pUser.append($texte);
				$divUsers.appendChild($pUser);
			}
		})
		.catch(() => {
			alert("ERREUR");
		});
}
//---------------------------------
