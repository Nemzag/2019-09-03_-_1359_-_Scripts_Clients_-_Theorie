"use strict";

let app = new Vue({
    el: "#app",
    data: {
        hdep: 0,
        temps: "",
        etat: "P", // P = prêt, F = en fonction, A = arrêt
        laps: []
    },
    methods: {
        startChrono(){
            this.etat = "F";
            this.hdep = new Date();
            this.timer = setInterval(this.majTemps, 1);
        },
        stopChrono(){
            this.etat = "A";
            clearInterval(this.timer);
        },
        resetChrono(){
            this.etat = "P";
            this.temps = tps2Str(0);
            this.laps = [];
        },
        addLapTime(){
            this.laps.push(this.temps);
        },
        majTemps(){
            this.temps = tps2Str(new Date() - this.hdep);
        }
    }
});

function tps2Str(tps_ms) {
    let tps = new Date(tps_ms);

    let heures = tps.getUTCHours().toString().padStart(2, "0");
    let minutes = tps.getUTCMinutes().toString().padStart(2, "0");
    let secondes = tps.getUTCSeconds().toString().padStart(2, "0");
    let millisecondes = tps.getUTCMilliseconds().toString().padStart(3, "0");

    return `${heures}:${minutes}:${secondes}.${millisecondes}`;
}