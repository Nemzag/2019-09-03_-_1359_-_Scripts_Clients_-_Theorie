"use strict";

let app = new Vue({
    el: "#app",
    data: {
        nom: "",
        loisirs:["Bière", "Sieste", "JavaScript", "Lire"],
        affLoisirs : true
    }
});