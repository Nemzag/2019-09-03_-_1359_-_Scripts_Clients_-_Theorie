"use strict";

const TXT_NOM = document.getElementById("txtNom");
const SPAN_NOM = document.getElementById("spanNom");

TXT_NOM.addEventListener("keyup", majSpanNom);

function majSpanNom() {
    SPAN_NOM.innerHTML = TXT_NOM.value;
}