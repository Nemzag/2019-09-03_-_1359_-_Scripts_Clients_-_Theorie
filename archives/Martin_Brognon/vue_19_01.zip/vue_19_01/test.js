let app = new Vue({
    el: "#app",
    data: {
        a: 0,
        b: 0
    },
    computed: {
        carreB() {
            console.log("carré de " + this.b);
            return this.b * this.b;
        }
    }
});