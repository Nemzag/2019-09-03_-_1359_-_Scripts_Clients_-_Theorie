let app = new Vue({
    el: "#app",
    data: {
        listePays: [],
        paysChoisis: [], // v-model lié avec les cases à cocher pays
        listePers: [],
        idPSel: 0, // v-model lié avec le select des personnes
        etat: "" // Gestion des états : "" -> "etatChoixPays" -> "etatInscription"
    },
    methods: { // Gestion des états
        etatChoixPaysEntry() {
            this.listePays = []; // Initialisation de la liste des pays

            fetch("./listePays.php") // Requête : liste des pays
                .then(rep => rep.json()) // On transforme les données en format JSON
                .then(liste => {
                    // Ajout à la liste des pays
                    this.listePays = []; // On vide le tableau listePays
                    for(let pays of liste) {
                        this.listePays.push(pays.paysP); // On ajoute les données dans le tableau listePays
                    }
                    // Quand la liste est chargée (Promise)
                    this.listePays.sort((a,b) => a.localeCompare(b)); // On trie les pays par ordre alphabétique
                    this.etat = "etatChoixPays"; // Passage à l'état suivant
                });
        },
        commencerInscr() {
            if(!this.etatChoixPays || this.nbPaysChoisis == 0) { // Si je ne suis pas dans l'état choix pays ou que je n'ai choisi aucun pays
                return; // Je quitte
            }
            this.etatInscriptionEntry();
        },
        etatInscriptionEntry() {
            // Initialisation de la liste des personnes
            this.listePers = [];

            // Gestion des promesses
            let promesses = []; // Tableau de promesses

            this.paysChoisis.forEach(pays => { // Pour chaque pays coché
                let promesse = fetch("./listePersUnPays.php?pays=" + pays) // Requête : liste des personnes
                    .then(rep => rep.json())
                    .then(liste => {
                        // Ajout à la liste des personnes
                        for(let pers of liste) {
                            pers.selectionne = false; // On met l'attribut selectionne à la valeur false
                            this.listePers.push(pers); // On ajoute les personnes dans le tableau listePers
                        }
                    });
                promesses.push(promesse);
            });
            // Le travail continuera lorsque tous les pays seront traités
            Promise.all(promesses).then(() => {
                this.listePers.sort((a,b)=> (a.nomP + a.prenomP).localeCompare(b.nomP + b.prenomP)); // On trie les personnes par ordre alphabétique sur le nom et le prénom
                this.etat = "etatInscription"; // Passage à l'état suivant
            });
        },
        ajouter() {
            if(!this.etatInscription) return; // Si on n'est pas dans l'état inscription, on quitte
            let p = this.listePers.find(el => el.idP === this.idPSel);
            p.selectionne = true;
        },
        supprimer(ev) {
            if(!this.etatInscription) return;
            let idx = ev.target.value; // idx veut dire index
            let p = this.listePers.find(el => el.idP === idx);
            p.selectionne = false;
        }
        /*
        Quand on utilise des tableaux, il y a des méthodes importantes à savoir : sort(), filter() and find(). filter() renvoie tous les résultats et find() ne renvoie qu'un seul résultat
         */
    },
    computed: { // Pseudo variables
        etatChoixPays() {
            return this.etat === "etatChoixPays";
        },
        etatInscription() {
            return this.etat === "etatInscription";
        },
        nbPaysChoisis() {
            return this.paysChoisis.length; // Returns the number of elements of the array paysChoisis
        },
        persChoisies() { // Liste des personnes sélectionnées
            return this.listePers.filter(el => el.selectionne);
        },
        masseTotale() { // Calcul du total des masses des personnes sélectionnées
            return this.persChoisies.reduce((a, e) => a + Number(e.masseP), 0); // La méthode Number() sert à convertir en nombre une chaîne de caractères
        }
    },
    mounted() {
        this.etatChoixPaysEntry(); // Passage à l'état suivant
    }
});