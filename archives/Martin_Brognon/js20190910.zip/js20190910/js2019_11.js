"use strict";

document.getElementById("btnReq").addEventListener("click", reqAjax);

function reqAjax() {
    let $num = document.getElementById("txtNum").value; // On stocke le nombre du champ.

    let $request = new XMLHttpRequest(); // On instancie un objet XMLHttpRequest
    $request.open("GET", "./ex2019_11.php?num=" + $num, true); // Le premier argument contient la méthode d'envoi des données.
    // Le deuxième argument est l'URL à laquelle on souhaite soumettre notre requête.
    // Le troisième argument est un booléen facultatif dont la valeur par défaut est true. A true, la requête sera de type asynchrone, à false elle sera synchrone.
    // Cette ligne de code prépare une requête afin que cette dernière contacte la page ex2019_11.php. Tout paramètre spécifié à la requête sera transmis par le biais de la méthode GET.
    $request.addEventListener("readystatechange", function() {
        if($request.readyState === 4 && $request.status === 200) {
            let $reponse = JSON.parse($request.responseText); // $reponse contient la réponse du service web au format texte. On transforme le texte en objet JavaScript avec la fonction JSON.parse($request.responseText).
            let $texte = "";
            for (const ITEM in $reponse) {
                $texte += ITEM + " : " + $reponse[ITEM] + "<br>";
            }
            document.getElementById("divResult").innerHTML = $texte;
        }
    }); // Dans le cas d'une requête asynchrone, il nous faut spécifier une fonction de callback afin de savoir quand la requête s'est terminée. Pour cela, l'objet XMLHttpRequest possède un événement nommé readystatechange auquel il suffit d'attribuer une fonction.
    // Cependant, cet événement ne se déclenche pas seulement lorsque la requête est terminée, mais plutôt, comme son nom l'indique, à chaque changement d'état.
    // L'utilisation de la propriété readyState est nécessaire pour connaître l'état de la requête. L'état qui nous intéresse est la constante DONE car nous voulons simplement savoir quand notre requête est terminée.
    // De cette manière, notre code ne s'exécutera pas lorsque la requête aura terminé son travail. Toutefois, même si la requête a terminé son travail, cela ne veut pas forcément dire qu'elle l'a mené à bien, pour cela nous allons devoir consulter le statut de la requête grâce à la propriété status. Cette dernière renvoie le code correspondant à son statut, comme le fameux 404 pour les fichiers non trouvés. On veut vérifier si tout s'est bien passé (200).

    $request.send(null); // Après préparation de la requête, il ne reste plus qu'à l'envoyer avec la méthode send(). Cette dernière prend en paramètre un argument obligatoire.
    // Après exécution de cette méthode, l'envoi de la requête commence.
}