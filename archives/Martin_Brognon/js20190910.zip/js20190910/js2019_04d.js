"use strict";

radioButtonsValue("operator");

// On stocke toutes les entrées du formulaires dans des constantes
const $txtNbre1 = document.getElementById("txtNbre1");
const $txtNbre2 = document.getElementById("txtNbre2");
const $optOpPlus = document.getElementById("optOp+");
const $optOpMoins = document.getElementById("optOp-");
const $optOpFois = document.getElementById("optOp*");
const $optOpDiv = document.getElementById("optOp/");
const $txtResult = document.getElementById("txtResult");
const $grpOp = document.getElementById("grpOp");

// On ajoute des écouteurs d'événements
$txtNbre1.addEventListener("keyup", calculer);
$txtNbre2.addEventListener("keyup", calculer);
$optOpPlus.addEventListener("click", calculer);
$optOpMoins.addEventListener("click", calculer);
$optOpFois.addEventListener("click", calculer);
$optOpDiv.addEventListener("click", calculer);
$grpOp.addEventListener("grpOp", calculer);

function calculer() {
    let $nb1 = parseInt($txtNbre1.value);
    let $nb2 = parseInt($txtNbre2.value);
    let $result;

    switch(radioButtonsValue("operator")) {
        case '+':
            $result = $nb1 + $nb2;
            break;
        case '-':
            $result = $nb1 - $nb2;
            break;
        case '*':
            $result = $nb1 * $nb2;
            break;
        case '/':
            $result = $nb1 / $nb2;
            break;
        default:
            break;
    }

    return $txtResult.value = $result;
}

// Fonction permettant de récupérer la valeur de l'opérateur choisi par l'utilisateur
function radioButtonsValue($grpBoutonsRadios) {
    let $tabBoutonsRadio = document.getElementsByName($grpBoutonsRadios);

    console.log('tabBoutonsRadio :', $tabBoutonsRadio);

    for(let $i = 0; $i < $tabBoutonsRadio.length; $i++) {
        if($tabBoutonsRadio[$i].checked) {
            return $tabBoutonsRadio[$i].value;
        }
    }

    return null;
}