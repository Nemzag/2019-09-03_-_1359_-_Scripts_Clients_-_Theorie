"use strict";
//-------------------------------------
// code appelé automatiquement
//-------------------------------------

//document.getElementById("btnSaluer").addEventListener("click", saluer());
document.getElementById("btnSaluer").addEventListener("click", saluer);

//-------------------------------------
// outils
//-------------------------------------
function saluer() {
	window.alert("Bonjour");
}
