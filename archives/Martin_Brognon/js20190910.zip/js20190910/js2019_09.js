"use strict";

const $txtResult = document.getElementById("txtResult");

document.getElementById("btnCalculer").addEventListener("click", calculer);

function calculer() {
    let $txtNbre1 = getRandomIntInclusive(0, 10);
    let $txtNbre2 = getRandomIntInclusive(0, 10);
    document.getElementById("txtNbre1").value = $txtNbre1;
    document.getElementById("txtNbre2").value = $txtNbre2;
    let result = $txtNbre1 + $txtNbre2;

    $txtResult.value = result;
}

function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min +1)) + min;
}