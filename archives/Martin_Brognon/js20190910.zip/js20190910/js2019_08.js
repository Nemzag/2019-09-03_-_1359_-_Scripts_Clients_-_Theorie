"use strict";

// Devoir : afficher l'heure de l'ordinateur (avec les dixièmes de secondes)
/*
if(heure > Date(2019, 08, 24, 18, 0, 0))
 */

/*
La méthode setInterval a pour premier paramètre une fonction qui elle-même appelle une fonction de nom afficherHeureCourante et une durée exprimée en millisecondes (1000 = 1 seconde) correspondant au rythme d'actualisation de l'affichage de l'heure système au format hh:mm:ss.
 */

/*
Un span identifié par heureEnCours est aussi prévu pour recevoir l'affichage généré par la fonction afficherHeureCourante.
 */
/*let monHeure = setInterval(
    function()
    {
        afficherHeureCourante()
    }, 1000
);*/

setInterval(afficherHeureCourante, 100);

/*
L'heure système (date système) est récupérée par instanciation d'un objet de type Date dans la variable maReferenceTemps.
 */

/*
Une conversion de la partie heures/minutes/secondes de cette date est ensuite assurée avec le formalisme local (hh:mm:ss).
 */
function afficherHeureCourante()
{
    // Récupération de l'heure de l'ordinateur
    let $maReferenceTemps = new Date();

    let $heures = $maReferenceTemps.getHours();
    let $minutes = $maReferenceTemps.getMinutes();
    let $secondes = $maReferenceTemps.getSeconds();
    let $dixiemes = Math.floor($maReferenceTemps.getMilliseconds() / 100);

    // let $var = 9.6666;
    // Math.round($var) => arrondit le nombre (10)
    // Math.floor($var) => arrondit le nombre par défaut (9)
    // Math.ceil($var) => arrondit le nombre par excès (10)

    if($minutes < 10) {
        $minutes = "0" + $minutes;
    }

    // Conversion de l'heure système en format local (hh:mm:ss)
    //let hmsd = maReferenceTemps.toLocaleTimeString();
    let $hmsd = ($heures < 10 ? "0" + $heures : $heures) + ":" + ($minutes < 10 ? "0" + $minutes : $minutes) + ":" + ($secondes < 10 ? "0" + $secondes : $secondes) + "." + $dixiemes;

    // Affichage dans le span heureEnCours
    document.getElementById("heureEnCours").innerHTML = $hmsd;
}