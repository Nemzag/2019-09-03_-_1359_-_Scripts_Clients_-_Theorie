"use strict";
//-------------------------------------
// code appelé automatiquement
//-------------------------------------
const $txtNbre1 = document.getElementById("txtNbre1");
const $cboOperator = document.getElementById("cboOperator");
const $txtNbre2 = document.getElementById("txtNbre2");
const $txtResult = document.getElementById("txtResult");

// La méthode addEventListener() associe un gestionnaire d'événements à l'élément spécifié.
// La méthode addEventListener() associe un gestionnaire d'événements à un élément sans remplacer les gestionnaires d'événements existants.
// Cette méthode addEventListener() facilite le contrôle de la réaction de l'événement au bullage.
// Lors de l'utilisation de la méthode addEventListener(), le JavaScript est séparé du balisage HTML pour une meilleure lisibilité et vous permet d'ajouter des écouteurs d'événements même lorsque vous ne contrôlez pas le balisage HTML.
// Vous pouvez facilement supprimer un écouteur d'événement en utilisant la méthode removeEventListener().
// Syntaxe : element.addEventListener(event, function, useCapture);
// Le premier paramètre est le type de l'événement (comme "click" ou "mousedown" ou tout autre événement HTML DOM).
// Le deuxième paramètre est la fonction que nous voulons appeler lorsque l'événement se produit.
// Le troisième paramètre est une valeur booléenne spécifiant s'il faut utiliser la propagation d'événements ou la capture d'événements. Ce paramètre est optionnel.
// Notez que vous n'utilisez pas le préfixe "on" pour l'événement; utilisez "click" au lieu de "onclick".
$txtNbre1.addEventListener("keyup", calculer);
$cboOperator.addEventListener("change", calculer);
$txtNbre2.addEventListener("keyup", calculer);
// Utiliser change à la place de keyup car dès que quelque chose change, il active la méthode.

//-------------------------------------
// outils
//-------------------------------------
function calculer() {
    let $nb1 = parseInt($txtNbre1.value);
    let $nb2 = parseInt($txtNbre2.value);
    let $result;

    switch($cboOperator.value) {
        case '+':
            $result = $nb1 + $nb2;
            break;
        case '-':
            $result = $nb1 - $nb2;
            break;
        case '*':
            $result = $nb1 * $nb2;
            break;
        case '/':
            if($nb2 === 0) {
                window.alert("Division par 0 impossible !");
            }
            $result = $nb1 / $nb2;
            break;
        default:
            break;
    }

    return $txtResult.value = $result;
}
// Une variable est undefined quand elle ne contient rien.
// cbo : combo box
// txt : texte
// lbl : label
// lst : liste
// opt : option