<?php

$num = $_GET["num"];
if($num == 1){echo '{"nom":"Dubois", "prenom":"Louis", "age":"25"}';}
elseif ($num == 2){echo '{"nom":"Leroy", "prenom":"Albert", "couleur":"or"}';}
elseif ($num == 3){echo '{"nom":"Leroy", "prenom":"Philippe"}';}
elseif ($num == 4){echo '{"nom":"Terrieur", "prenom":"Alain"}';}
else {
    echo '{"nom":"Doe", "prenom":"John"}';
}