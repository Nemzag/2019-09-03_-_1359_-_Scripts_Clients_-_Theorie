"use strict";

const $lblMarie = document.getElementById("lblMarie");
const $pNomConj = document.getElementById("pNomConj");
//const $txtNomConj = document.getElementById("txtNomConj");

document.getElementById("optF").addEventListener("click", function() {
    $lblMarie.textContent = "Mariée";
});

document.getElementById("optM").addEventListener("click", function() {
    $lblMarie.textContent = "Marié";
});

document.getElementById("estMarie").addEventListener("click", function() {
    if(this.checked) { // This représente l'objet où on se trouve
        $pNomConj.style.display = "block";
    } else {
        $pNomConj.style.display = "none";
        //$txtNomConj.value = null; => pour empêcher que le nom du conjoint soit enregistré quand on a sélectionné marié/mariée, donné le nom du conjoint et décoché la case
    }
});