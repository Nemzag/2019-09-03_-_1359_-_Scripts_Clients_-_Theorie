"use strict";

// gestion participants

function constructionListePart() {
    $cboPers.innerHTML = "";
    lstPers = [];
    [...$divPays.getElementsByClassName("chk-pays")]
        .filter(el => el.checked) // Pour chacun des éléments du tableau, je ne prends que ce qui est coché.
        //.sort((a,b) => a.paysP.localeCompare(b.paysP))
        .forEach(pays => { // Pour chacun des éléments cochés, je commence le travail.
            fetch("./listePersUnPays.php?pays=" + pays.value)
                .then(rep => rep.json())
                .then(listePers => {
                    for (const pers of listePers.sort((x,y) => x.nomP.localeCompare(y.nomP))) { // Fait une comparaison en fonction des paramètres locaux.
                        pers.dispo = true;
                        pers.IMC = pers.masseP / Math.pow(pers.tailleP / 100.0, 2);
                        lstPers[pers.idP] = pers;

                        let $optPers = document.createElement("option");
                        $optPers.innerHTML = `${pers.nomP} ${pers.prenomP}`;
                        $optPers.value = pers.idP;
                        $cboPers.appendChild($optPers);
                    }
                });
        });
    console.log("lstPers : ", lstPers);
}

function ajouterPart() {
    let pers = lstPers[$cboPers.value];
    let $pPart = document.createElement("p");

    let $btnSuppPart = document.createElement("button");
    $btnSuppPart.innerHTML = "-";
    $btnSuppPart.addEventListener("click", supprimerPart);

    let $txtPart = document.createTextNode(
        `${pers.idP} --> ${pers.nomP} ${pers.prenomP} (${pers.masseP})`
    );

    $pPart.appendChild($btnSuppPart);
    $pPart.appendChild($txtPart);
    $pPart.classList.add("Lg-Part");
    $pPart.setAttribute("idP", pers.idP);
    $pPart.setAttribute("masseP", pers.masseP);

    masseTotale += Number(pers.masseP);
    $spanMassetotale.innerHTML = masseTotale;

    $divPart.appendChild($pPart);
}

function supprimerPart() {
    let $li = this.closest(".Lg-Part"); // Pointe sur la ligne du participant que l'on veut supprimer.

    masseTotale -= $li.getAttribute("masseP");
    $spanMassetotale.innerHTML = masseTotale; // On met à jour la masse totale.

    $li.remove(); // On supprime le participant.
}

// gestion états(phases)...

function commencerChoix() {
    // désactiver les éléments du cadre choix Pays

    [...$divPays.getElementsByClassName("")]
}

// gestion liste pays...

function constructionListePays() {
    fetch("./listePays.php")
        .then(rep => rep.json())
        .then(listePays => {
            $divPays.innerHTML = "";
            for (const pays of listePays.sort((a,b) =>
            a.paysP.localeCompare(b.paysP))) {
                lstPays.push(pays.paysP); // pour utilisation future

                let $pPays = document.createElement("p");
                $pPays.classList.add("p-pays");
            }
        })
}