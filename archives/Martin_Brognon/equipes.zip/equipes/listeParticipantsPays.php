<?php
$pays = $_GET['pays']; // $pays contient soit une chaîne vide soit une série de un ou plusieurs pays séparés par un ;


$pdo = new PDO(
    'mysql:host=localhost; dbname=population2019; charset=utf8',
    'root',
    ''
);

// On va construire une condition SQL au départ de $pays (boucle)
$tabPays = explode(';', $pays);

if (count($tabPays) == 0)
{
    $chaineSQL = " paysP = ''";
}
else
{
    $chaineSQL = " ";
    for($i = 0; $i < count($tabPays) ; $i++) {
        $chaineSQL .= "paysP = '" . $tabPays[$i] . "'";
        if ($i < count($tabPays) - 1) { // il reste au moins un pays à analyser
            $chaineSQL .= " OR ";
        }
    }
}

$statement = $pdo->prepare("SELECT * FROM personnes WHERE" . $chaineSQL . "ORDER BY paysP");
//$statement->execute([':condSQLPays' => $chaineSQL]); --- ne fonctionne pas. Pourquoi ???
$statement->execute();

$results = $statement->fetchAll(PDO::FETCH_ASSOC);

$json = json_encode($results);

echo $json;
