"use strict";

// Pas eu le temps de regarder

let lstPers;

function constructionListePart() {
    $cboPers.innerHTML = "";
    lstPers = [];
    [...$divPays.getElementsByClassName("chk-pays")]
        .filter(el => el.checked)
        .forEach(pays => {
            fetch("./listePersUnPays.php?pays=" + pays.value)
                .then(rep => rep.json())
                .then(listePers => {
                    for (const pers of listePers) {
                        pers.dispo = true;
                        (pers.IMC = pers.masseP / Math.pow(pers.tailleP / 100.0 ,2));
                        lstPers[pers.idP] = pers;

                    }
                })
        })
}