"use strict";

// Variables globales
// L'objet document permet de récupérer des éléments HTML et de les manipuler.
// Ici on sélectionne l'élément HTML qui a pour id divPays et on le stocke dans la variable $divPays qui est de type objet (équivalent à un tableau associatif en PHP).
let $divPays = document.getElementById("divPays");
// Ici on sélectionne l'élément HTML qui a pour id divParticipants et on le stocke dans la variable $divParticipants qui est de type objet (équivalent à un tableau associatif en PHP).
let $divParticipants = document.getElementById("divParticipants");
let $btnAjouter = document.getElementById("ajouter");
// let $btnSupprimer = document.getElementsByName("boutonsSupprimer")
// 2do ___ let $btnEnregistrer = document.getElementById("enregistrer");

// Ecouteurs d'événements
// Ici on ajoute un écouteur d'événements sur la variable $divPays. Le type d'événement change a pour action de changer la valeur d'un élément spécifique aux formulaires (input, checkbox, etc.).
$divPays.addEventListener("change", updateListeParticipants);
$btnAjouter.addEventListener("click", ajouterUnParticipant);
// 2do ___$btnEnregistrer.addEventListener("click", enregistrerParticipant);
//$btnSupprimer.addEventListener("click", supprimerUnParticipant);

// Appel de la fonction
listePays();


// Les fonctions

// Fonction affichant la liste des pays
function listePays() {

    fetch("listePays.php")
        .then($reponse => $reponse.json())
        .then($data => {
            for(const COUNTRY of $data) {
                let $checkbox = document.createElement("input");
                $checkbox.setAttribute("type", "checkbox");
                $checkbox.setAttribute("name", "country");
                $checkbox.setAttribute("id", COUNTRY.paysP);
                $checkbox.setAttribute("value", COUNTRY.paysP);
                $checkbox.setAttribute("title", COUNTRY.paysP);
                let $label = document.createElement("label");
                $label.setAttribute("for", COUNTRY.paysP);
                $label.innerHTML = COUNTRY.paysP;

                let $divCheckbox = document.createElement("div");

                $divPays.appendChild($divCheckbox);
                $divCheckbox.appendChild($checkbox);
                $divCheckbox.appendChild($label);
            }
        });
}

// Fonction mettant à jour les participants
function updateListeParticipants() {

    // Construire la condition SQL en fonction des cases cochées des pays
    // La variable $conditionSQL contient une chaîne de caractères vide.
    let $paysChecked = "";
    // Ici on sélectionne les éléments HTML dont la valeur de l'attribut name est country et on les stocke dans la variable $checkboxPays qui est de type objet (équivalent à un tableau associatif en PHP).
    let $checkboxPays = document.getElementsByName("country");
    // Initialisation de la boucle
    let $i = 0;
    // Tant que la variable de parcours de boucle est inférieure à la longueur (nombre d'éléments) du tableau $checkboxPays
    while($i < $checkboxPays.length) {
        // Si l'élément du tableau est coché
        if($checkboxPays[$i].checked){
            // On stocke le nom du pays dans la variable string $paysChecked terminée par un ';'.
                $paysChecked += $checkboxPays[$i].value + ';';
        }
        $i++;
    }


    // Appel vers la BD et màj des participants

    fetch("listeParticipantsPays.php?pays=" + $paysChecked)
        .then($reponse => $reponse.json())
        .then($data => {

            /* Effacer la liste (arborescence) d'une précédente requête*/

            while( $divParticipants.firstChild) { // tant que le div des participants a un premier fils, effacer celui-ci
                $divParticipants.removeChild($divParticipants.firstChild);
            }

            // 2do

            /* Afficher résultats de la nouvelle requête*/

            for(const PARTICIPANTS of $data) {

                let $divCheckboxPart = document.createElement("div");
                $divParticipants.appendChild($divCheckboxPart);


               let $checkboxPart = document.createElement("input");
                $checkboxPart.setAttribute("type", "checkbox");
                $checkboxPart.setAttribute("name", "participants");
                $checkboxPart.setAttribute("id", PARTICIPANTS.idP);
                $checkboxPart.setAttribute("value", PARTICIPANTS.idP);
                $checkboxPart.setAttribute("title", PARTICIPANTS.idP);


                let $labelPart = document.createElement("label");
                $labelPart.setAttribute("for", PARTICIPANTS.idP);
                $labelPart.innerHTML = PARTICIPANTS.nomP + ' ' + PARTICIPANTS.prenomP + ' ' + PARTICIPANTS.sexeP + ' ' + PARTICIPANTS.dnaissP + ' ' + PARTICIPANTS.villeP + ' ' + PARTICIPANTS.paysP + ' ' + PARTICIPANTS.tailleP + ' ' + PARTICIPANTS.masseP;

                let $buttonPart = document.createElement("button");
                // $buttonPart.value = PARTICIPANTS.idP;
                $buttonPart.setAttribute("id", PARTICIPANTS.idP);
                $buttonPart.setAttribute("name", "boutonsSupprimer");
                $buttonPart.innerHTML = 'Supprimer';


                $divCheckboxPart.appendChild($checkboxPart);
                $divCheckboxPart.appendChild($labelPart);
                $divCheckboxPart.appendChild($buttonPart);
            }

        });
}

function ajouterUnParticipant()
{
    let $form = document.getElementById("myForm");
    $form.style.display = 'block';
}

/*function enregistrerParticipant()
{
    updateListeParticipants();
}*/

function supprimerUnParticipant($id)
{
   fetch('supprimerUnParticipant.php?id=' + $id);
   // updateListeParticipants()
}

/*function majParticipants() {
    $participants.innerHTML = "";
    $participants.appendChild($optVide.cloneNode(true));
    $divParticipants.hidden = true;

    let $pays = $participants.value;

    if($pays < 0) {
        return;
    }

    fetch("./listePersUnPays.php?pays=" + $pays)
        .then($reponse => $reponse.json())
        .then($listeParticipants => {
            if($listeParticipants.length === 1) {
                let $optParticipant = document.createElement("option");
                $optParticipant.innerHTML = $listeParticipants[0].nomP;

                $participants.innerHTML = "";
                $participants.appendChild($optParticipant);
            } else {
                for(let $participant of $listeParticipants) {
                    let $optParticipant = document.createElement("option");
                    $optParticipant.innerHTML = $participant.nomP;

                    $participants.appendChild($optParticipant);
                }
            }
        });

    $divParticipants.hidden = false;
}*/