
<?php

//$id = $_GET['id'];

$id =2;

$pdo = new PDO(
    'mysql:host=localhost; dbname=population2019; charset=utf8',
    'root',
    ''
);

$statement = $pdo->prepare("DELETE FROM personnes WHERE idP = :id");
$statement->bindValue('id', $id, PDO::PARAM_INT);
$statement->execute();