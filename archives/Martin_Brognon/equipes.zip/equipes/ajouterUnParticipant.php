<?php

$lastName = $_GET['lastName'];
$firstName = $_GET['firstName'];
$sex = $_GET['sex'];
$birthday = $_GET['birthday'];
$town = $_GET['town'];
$country = $_GET['country'];
$size = $_GET['size'];
$weight = $_GET['weight'];

$pdo = new PDO(
    'mysql:host=localhost; dbname=population2019; charset=utf8',
    'root',
    ''
);

$statement = $pdo->prepare("INSERT INTO personnes (nomP, prenomP, sexeP, dnaissP, villeP, paysP, tailleP, masseP) VALUES (:lastName, :firstName, :sex, :birthday, :town, :country, :size, :weight)");
$statement->bindValue('lastName', $lastName, PDO::PARAM_STR);
$statement->bindValue('firstName', $firstName, PDO::PARAM_STR);
$statement->bindValue('sex', $sex, PDO::PARAM_STR);
$statement->bindValue('birthday', $birthday, PDO::PARAM_STR);
$statement->bindValue('town', $town, PDO::PARAM_STR);
$statement->bindValue('country', $country, PDO::PARAM_STR);
$statement->bindValue('size', $size, PDO::PARAM_INT);
$statement->bindValue('weight', $weight, PDO::PARAM_INT);
$statement->execute();