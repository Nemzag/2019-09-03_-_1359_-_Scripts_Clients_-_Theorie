"use strict";
const CBO_CP = document.getElementById("cboCP");
const CBO_LOC = document.getElementById("cboLoc");
const DIV_LOC = document.getElementById("divLoc");

CBO_CP.addEventListener("click", majCboCP);
CBO_CP.addEventListener("change", majCboLoc);

let $optVide = document.createElement("option");
$optVide.innerHTML = "Choisissez...";
$optVide.value = "-1";

function majCboCP() {
    fetch("listeTousLesCP.php") // Requête AJAX
        .then($reponse => $reponse.json()) // Transformer la réponse (texte) en tableau d'objets JSON
        .then($listeCP => {
            // Nettoyage du <select>
            CBO_CP.innerHTML = "";
            CBO_CP.appendChild($optVide.cloneNode(true));

            // Parcours du tableau d'objets JSON
            for(let $cp of $listeCP) {
                // Création de l'<option> + paramètres
                let $optCP = document.createElement("option");
                $optCP.innerHTML = $cp.CP;
                $optCP.value = $cp.CP;
                // Ajout de l'<option> au <select>
                CBO_CP.appendChild($optCP);
            }

            //CBO_LOC.setAttribute("disabled", "");
            //CBO_LOC.hidden = true;
            //DIV_LOC.hidden = true;
        });
}

function majCboLoc() {
    CBO_LOC.innerHTML = "";
    CBO_LOC.appendChild($optVide.cloneNode(true));
    //CBO_LOC.setAttribute("disabled", "");
    //CBO_LOC.hidden = true;
    DIV_LOC.hidden = true;

    let $cp = CBO_CP.value; // La valeur du CP choisi

    if($cp < 0) {
        return;
    }

    fetch("./listeCommunesPourUnCP.php?cp=" + $cp)
        .then($reponse => $reponse.json())
        .then($listeCommunes => {
            if($listeCommunes.length === 1) {
                let $optCommune = document.createElement("option");
                $optCommune.innerHTML = $listeCommunes[0].Commune;

                CBO_LOC.innerHTML = "";
                CBO_LOC.appendChild($optCommune);
            } else {
                for(let $commune of $listeCommunes) {
                    let $optCommune = document.createElement("option");
                    $optCommune.innerHTML = $commune.Commune;

                    CBO_LOC.appendChild($optCommune);
                }
            }
        });

    //CBO_LOC.removeAttribute("disabled");
    //CBO_LOC.hidden = false;
    DIV_LOC.hidden = false;
}