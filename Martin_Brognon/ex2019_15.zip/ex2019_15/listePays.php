<?php

$filtre= $_GET['filtrePays'];

$dsn = 'mysql:dbname=paysmonde;host=localhost;charset=utf8';
$username = 'root';
$passwd = '';

try {

    $dbh = new PDO($dsn, $username, $passwd);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$sql = "SELECT idP, nomFrP FROM pays WHERE nomFrP LIKE :filtre ORDER BY nomFrP;";
$results = $dbh->prepare($sql);
$results->execute([':filtre'=>'%'. $filtre .'%']);

$data = $results->fetchAll(PDO::FETCH_ASSOC);

$json = json_encode($data);
echo $json;

