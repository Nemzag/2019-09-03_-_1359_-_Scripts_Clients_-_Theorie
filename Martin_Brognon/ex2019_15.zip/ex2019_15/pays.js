"use strict";
let $txtFiltre = document.getElementById("txtFiltre"); // On récupère l'élément sur lequel on veut détecter le relâchement d'une touche
let $btnStore = document.getElementById("btnStore");
let $divResult = document.getElementById("divResult");
let $blankRow = document.getElementById("divRow").cloneNode(true);
$blankRow.removeAttribute("id");
$blankRow.setAttribute("id", "divRow");

$divResult.innerHTML = "";

$txtFiltre.addEventListener("keyup", request); // On écoute l'événement keyup
$btnStore.addEventListener("click", () => {
    let $list = document.getElementsByClassName("check");
    for (let country of $list){

    }
});

function request(){
    $divResult.innerHTML = "";
    // On insère le paramètre $filtrePays
    fetch("listePays.php?filtrePays=" + $txtFiltre.value.trim())
        .then(rep => rep.json())
        .then(data => {
            for(const country of data){
                console.log(country);
                let $newRow = $blankRow.cloneNode(true);
                $newRow.getElementsByTagName("input")[0].setAttribute("country", country.nomFrP);
                $newRow.getElementsByTagName("label")[0].innerHTML = country.nomFrP;
                $divResult.appendChild($newRow); // On crée un paragraphe pour chaque pays affiché
            }
        });
}

/*
const $txtPays = document.getElementById("txtPays");
const $divListePays = document.getElementById("divListePays");
const $btnAjoutPays = document.getElementById("btnAjoutPays");

$txtPays.addEventListener("input", affListePays);
$btnAjoutPays.addEventListener("click", ajoutPays);

function affListePays() {
    //console.log("Liste des pays");
    let filtrePays = $txtPays.value.trim();
    //console.log("filtrePays :", filtrePays);

    fetch("listePays.php?filtrePays=" + filtrePays)
        .then(rep => rep.json())
        .then(listePays => {
            //console.log("listePays :", listePays);
            $divListePays.innerHTML = "";
            for (const pays of listePays) {
                //console.log("pays :", pays);
                let $pPays = document.createElement("p");
                $pPays.classList.add("p-pays");

                let $chkPays = document.createElement("input");
                $chkPays.type = "checkbox";
                $chkPays.classList.add("chk-pays");

                let $nomPays = document.createElement("span");
                $nomPays.innerHTML = pays.nomFrP;
                $nomPays.classList.add("nom-pays");
            }
         }
}
 */