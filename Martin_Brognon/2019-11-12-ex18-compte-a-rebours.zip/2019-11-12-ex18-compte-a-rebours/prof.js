"use strict";
// Constantes
const BTN_START = document.getElementById("btnStart");
const BTN_STOP = document.getElementById("btnStop");
const TXT_TEMPS = document.getElementById("txtTemps");
const DIV_PROGRESS_BAR_INT = document.getElementById("divPB_Int");

// Ecouteurs d'événements
BTN_START.addEventListener("click", start);
BTN_STOP.addEventListener("click", stop);

// Variables globales
let $timer;
let $tpsInit = 0;
let $tpsAct;

initPB();

// Fonctions
function start() {
    if(TXT_TEMPS.value < 1)
        return;

    $tpsInit = TXT_TEMPS.value;
    $tpsAct = $tpsInit;

    TXT_TEMPS.disabled = true;
    BTN_START.disabled = true;
    BTN_STOP.disabled = false;

    initPB();

    $timer = setInterval(majProgressBar, 1000);
}

function stop() {
    clearInterval($timer); // Arrêt du compte à rebours
    $timer = null;
    TXT_TEMPS.disabled = false;
    BTN_START.disabled = false;
    BTN_STOP.disabled = true;
}

function majProgressBar() {
    $tpsAct--;
    TXT_TEMPS.value = $tpsAct;
    affPB();
    if($tpsAct === 0)
        stop();
}

function affPB() {
    let $pc = ($tpsAct / $tpsInit) * 100;

    if($pc < 30)
        DIV_PROGRESS_BAR_INT.style.backgroundColor = "red";
    DIV_PROGRESS_BAR_INT.style.width = $pc + "%";
}

function initPB() {
    DIV_PROGRESS_BAR_INT.style.height = "100%";
    DIV_PROGRESS_BAR_INT.style.width = "100%";
    DIV_PROGRESS_BAR_INT.style.backgroundColor = "green";
}