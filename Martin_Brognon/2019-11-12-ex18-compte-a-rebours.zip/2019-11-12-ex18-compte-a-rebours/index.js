"use strict";
//const $time = document.getElementById("txtChrono");
//const $btnStart = document.getElementById("btnStart");
//const $btnStop = document.getElementById("btnStop");

//$btnStart.addEventListener("click", start);
//$btnStop.addEventListener("click", stop);

//let $startTime;
//let $timer;

//function start() {
    //$startTime = $time;

    //$timer = setInterval(affChrono, 1);
//}

//function stop() {
    //clearInterval($timer);
//}

//function affChrono() {
    //return $time.value;
//}

    let $downloadTimer;

      function start_countdown() {
          let $reverse_counter = 60;
          $downloadTimer = setInterval(function() {
              document.getElementById("pbar").value = 60 - --$reverse_counter;
              if($reverse_counter <= 0)
                  clearInterval($downloadTimer);
              document.getElementById("counting").innerHTML = $reverse_counter;
          }, 1000);
      }

      function stop_countdown() {
          clearInterval($downloadTimer);
      }